from sqlalchemy.orm import Session
from app.models.ad_groups import AdGroupRole


def resolve_role(db: Session, ad_groups: list) -> str | None:
    """
    Given a list of AD group names from the SAML assertion,
    return the highest role found in ad_group_roles table.
    Returns 'admin' > 'helpdesk' > None.
    """
    role = None
    for group in ad_groups:
        record = db.query(AdGroupRole).filter_by(group_name=group).first()
        if record:
            if record.role == "admin":
                return "admin"   # admin wins immediately
            if record.role == "helpdesk":
                role = "helpdesk"
    return role


def sync_groups(db: Session) -> dict:
    """
    Placeholder for AD sync logic.
    In production this would call the SECDS AD API to refresh
    group membership counts.
    Returns a summary of the sync result.
    """
    groups = db.query(AdGroupRole).all()
    return {
        "synced": len(groups),
        "groups": [g.group_name for g in groups],
    }
