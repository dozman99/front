from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta
from app.core.database import get_db
from app.core.deps import require_any, require_admin
from app.models.banned_users import BannedUser
from app.models.banned_apps import BannedApp
from app.models.audit_log import AuditLog
from app.models.message_log import MessageLog

router = APIRouter()


@router.get("/stats")
def get_stats(
    user=Depends(require_any),
    db: Session = Depends(get_db),
):
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0)
    tomorrow = today_start + timedelta(days=1)

    banned_apps   = db.query(BannedApp).filter(BannedApp.banned == True).count()
    banned_phones = db.query(BannedUser).filter(BannedUser.banned == True).count()
    opt_outs      = db.query(BannedUser).filter(BannedUser.opt_out == True).count()

    temp_expiring = db.query(BannedUser).filter(
        BannedUser.temp_ban == True,
        BannedUser.date_ban_expire >= today_start,
        BannedUser.date_ban_expire < tomorrow,
    ).count()

    throttled_today = db.query(MessageLog).filter(
        MessageLog.status == "throttled",
        MessageLog.attempted_at >= today_start,
    ).count()

    cap_hits_today = db.query(MessageLog).filter(
        MessageLog.block_reason == "cap_exceeded",
        MessageLog.attempted_at >= today_start,
    ).count()

    return {
        "banned_apps": banned_apps,
        "banned_phones": banned_phones,
        "temp_expiring_today": temp_expiring,
        "opt_outs": opt_outs,
        "throttled_today": throttled_today,
        "cap_hits_today": cap_hits_today,
    }


@router.get("/incidents")
def get_incidents(
    user=Depends(require_any),
    db: Session = Depends(get_db),
):
    """Auto-generate needs-attention incidents."""
    incidents = []
    now = datetime.utcnow()
    in_24h = now + timedelta(hours=24)

    # Temp bans expiring within 24 hours
    expiring = db.query(BannedUser).filter(
        BannedUser.temp_ban == True,
        BannedUser.banned == True,
        BannedUser.date_ban_expire >= now,
        BannedUser.date_ban_expire <= in_24h,
    ).all()

    for r in expiring:
        hours_left = (r.date_ban_expire - now).seconds // 3600
        incidents.append({
            "level": "warn",
            "entity": r.phone_number,
            "entity_type": "phone",
            "detail": f"Temp ban expires in {hours_left}h",
            "actions": ["Extend", "Lift Ban", "Make Permanent"],
        })

    # High auto-ban count numbers
    repeat = db.query(BannedUser).filter(
        BannedUser.auto_temp_ban_count >= 3,
    ).all()

    for r in repeat:
        incidents.append({
            "level": "warn",
            "entity": r.phone_number,
            "entity_type": "phone",
            "detail": f"Auto-banned {r.auto_temp_ban_count}x — approaching permanent threshold",
            "actions": ["View", "Make Permanent"],
        })

    return {"incidents": incidents, "count": len(incidents)}


@router.get("/activity")
def get_activity(
    user=Depends(require_any),
    db: Session = Depends(get_db),
):
    """Return last 20 audit log entries."""
    entries = db.query(AuditLog).order_by(
        AuditLog.performed_at.desc()
    ).limit(20).all()

    return [
        {
            "action": e.action,
            "entity": e.entity_value,
            "entity_type": e.entity_type,
            "performed_by": e.performed_by,
            "performed_at": e.performed_at.isoformat(),
            "reason": e.reason,
        }
        for e in entries
    ]


@router.get("/usage")
def get_usage(
    period: str = Query("today", description="today|week|month|all"),
    user=Depends(require_admin),
    db: Session = Depends(get_db),
):
    now = datetime.utcnow()
    if period == "today":
        since = now.replace(hour=0, minute=0, second=0)
    elif period == "week":
        since = now - timedelta(days=7)
    elif period == "month":
        since = now - timedelta(days=30)
    else:
        since = datetime(2000, 1, 1)

    q = db.query(MessageLog).filter(MessageLog.attempted_at >= since)

    attempted  = q.count()
    delivered  = q.filter(MessageLog.status == "delivered").count()
    throttled  = q.filter(MessageLog.status == "throttled").count()
    blocked    = q.filter(MessageLog.status.in_(["blocked_ban_app", "blocked_ban_phone"])).count()
    opt_out    = q.filter(MessageLog.status == "blocked_opt_out").count()
    cap_hits   = q.filter(MessageLog.block_reason == "cap_exceeded").count()

    return {
        "period": period,
        "attempted": attempted,
        "delivered": delivered,
        "throttled": throttled,
        "blocked": blocked,
        "opt_out": opt_out,
        "cap_hits": cap_hits,
    }
