from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional


class EmailRecord(BaseModel):
    email_address: str
    banned: bool
    temp_ban: bool
    date_banned: Optional[datetime] = None
    date_ban_expire: Optional[datetime] = None
    ban_reason: Optional[str] = None
    banned_by: Optional[str] = None
    date_unbanned: Optional[datetime] = None
    unbanned_by: Optional[str] = None
    unban_reason: Optional[str] = None
    msg_attempts: int
    last_msg_attempt: Optional[datetime] = None

    class Config:
        from_attributes = True


class EmailCreate(BaseModel):
    email_address: str
