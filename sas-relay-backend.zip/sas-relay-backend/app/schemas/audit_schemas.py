from pydantic import BaseModel
from datetime import datetime
from typing import Optional, Any


class AuditEntry(BaseModel):
    id: int
    action: str
    entity_type: str
    entity_value: str
    performed_by: str
    performed_at: datetime
    reason: Optional[str] = None
    metadata: Optional[Any] = None

    class Config:
        from_attributes = True


class AuditPage(BaseModel):
    items: list
    total: int
    page: int
    limit: int
    pages: int
