from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class PhoneRecord(BaseModel):
    phone_number: str
    banned: bool
    temp_ban: bool
    date_banned: Optional[datetime] = None
    date_ban_expire: Optional[datetime] = None
    ban_reason: Optional[str] = None
    banned_by: Optional[str] = None
    date_unbanned: Optional[datetime] = None
    unbanned_by: Optional[str] = None
    unban_reason: Optional[str] = None
    msg_attempts: int
    last_msg_attempt: Optional[datetime] = None
    opt_out: bool
    auto_temp_ban_count: int

    class Config:
        from_attributes = True


class PhoneCreate(BaseModel):
    phone_number: str


class PhoneOptOutUpdate(BaseModel):
    opt_out: bool
