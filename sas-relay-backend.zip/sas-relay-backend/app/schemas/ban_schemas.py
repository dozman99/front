from pydantic import BaseModel, field_validator, model_validator
from datetime import datetime
from typing import Optional


class BanRequest(BaseModel):
    is_temporary: bool
    expiry_date: Optional[datetime] = None
    reason: str

    @field_validator("reason")
    @classmethod
    def reason_not_empty(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Ban reason is required")
        if len(v) < 3:
            raise ValueError("Ban reason must be at least 3 characters")
        return v

    @model_validator(mode="after")
    def validate_expiry(self):
        if self.is_temporary:
            if not self.expiry_date:
                raise ValueError("Expiry date is required for temporary bans")
            from datetime import timedelta
            min_expiry = datetime.utcnow() + timedelta(hours=1)
            if self.expiry_date < min_expiry:
                raise ValueError("Expiry must be at least 1 hour from now")
        return self


class UnbanRequest(BaseModel):
    reason: str

    @field_validator("reason")
    @classmethod
    def reason_not_empty(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Unban reason is required")
        if len(v) < 3:
            raise ValueError("Unban reason must be at least 3 characters")
        return v
