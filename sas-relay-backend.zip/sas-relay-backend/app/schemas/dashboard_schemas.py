from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime


class DashboardStats(BaseModel):
    banned_apps: int
    banned_phones: int
    temp_expiring_today: int
    opt_outs: int
    throttled_today: int
    cap_hits_today: int


class IncidentItem(BaseModel):
    level: str          # critical | warn | info
    entity: str
    entity_type: str    # phone | email
    detail: str
    actions: List[str]


class ActivityItem(BaseModel):
    action: str
    entity: str
    entity_type: str
    performed_by: str
    performed_at: datetime
    reason: Optional[str] = None


class UsageStats(BaseModel):
    period: str
    attempted: int
    delivered: int
    throttled: int
    blocked: int
    opt_out: int
    cap_hits: int
