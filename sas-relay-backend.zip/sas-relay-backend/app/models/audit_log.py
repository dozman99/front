from sqlalchemy import Column, Integer, String, DateTime, Text
from sqlalchemy.dialects.postgresql import JSONB
from app.models.base import Base
from datetime import datetime


class AuditLog(Base):
    """App-owned table. Created by Alembic migration."""
    __tablename__ = "audit_log"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    action       = Column(String(50), nullable=False)
    entity_type  = Column(String(20), nullable=False)   # phone | email
    entity_value = Column(String(255), nullable=False)
    performed_by = Column(String(255), nullable=False)
    performed_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    reason       = Column(Text, nullable=True)
    metadata     = Column(JSONB, nullable=True)
