import api from '../lib/axios'
import type {
  DashboardStats,
  IncidentItem,
  ActivityItem,
  UsageData,
} from '../types'

export async function getStats(): Promise<DashboardStats> {
  const { data } = await api.get('/dashboard/stats')
  return data
}

export async function getIncidents(): Promise<IncidentItem[]> {
  const { data } = await api.get('/dashboard/incidents')
  return data
}

export async function getActivity(): Promise<ActivityItem[]> {
  const { data } = await api.get('/dashboard/activity')
  return data
}

export type UsagePeriod = 'today' | 'week' | 'month' | 'all'

export async function getUsage(period: UsagePeriod): Promise<UsageData> {
  const { data } = await api.get('/dashboard/usage', { params: { period } })
  return data
}
