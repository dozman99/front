import type { ReactNode } from 'react'

export interface Column<T> {
  header: string
  cell: (row: T) => ReactNode
  className?: string
}

interface Props<T> {
  columns: Column<T>[]
  rows: T[]
  rowKey: (row: T) => string
  onRowClick?: (row: T) => void
  renderRowActions?: (row: T) => ReactNode
}

// Lightweight table. Quick actions appear on row hover (controlled by parent).
export default function DataTable<T>({
  columns,
  rows,
  rowKey,
  onRowClick,
  renderRowActions,
}: Props<T>) {
  return (
    <div className="overflow-x-auto rounded-lg border border-[var(--color-border)]">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-[var(--color-border)] bg-[var(--color-surface)]">
            {columns.map((c) => (
              <th
                key={c.header}
                className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-[var(--color-muted)]"
              >
                {c.header}
              </th>
            ))}
            {renderRowActions && <th className="px-4 py-2.5" />}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr
              key={rowKey(row)}
              onClick={() => onRowClick?.(row)}
              className="group border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-accent)]/5 cursor-pointer"
            >
              {columns.map((c) => (
                <td key={c.header} className={`px-4 py-3 ${c.className ?? ''}`}>
                  {c.cell(row)}
                </td>
              ))}
              {renderRowActions && (
                <td className="px-4 py-3 text-right">
                  <span className="opacity-0 transition-opacity group-hover:opacity-100">
                    {renderRowActions(row)}
                  </span>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
