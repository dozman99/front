interface Props {
  value: number
  max: number
  // Optional explicit color; otherwise threshold-based green/amber/red.
  color?: string
  thresholds?: boolean
}

export default function ProgressBar({ value, max, color, thresholds }: Props) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0
  let barColor = color ?? 'var(--color-accent)'
  if (thresholds) {
    if (pct >= 80) barColor = 'var(--color-critical)'
    else if (pct >= 60) barColor = 'var(--color-warning)'
    else barColor = 'var(--color-safe)'
  }
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-[var(--color-border)]">
      <div
        className="h-full rounded-full transition-all"
        style={{ width: `${pct}%`, backgroundColor: barColor }}
      />
    </div>
  )
}
