import { useState } from 'react'
import { LayoutGrid } from 'lucide-react'
import { samlLogin } from '../api/auth'

// Login screen. In dev, POST /auth/saml/login returns a redirect_url pointing
// at the backend dev login page; in prod, the SECDS IDP. Frontend is identical
// in both modes — only the redirect target differs.
export default function Login() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)

  async function signIn() {
    setLoading(true)
    setError(false)
    try {
      const { redirect_url } = await samlLogin()
      // Brief intentional pause so the loading state is perceptible.
      setTimeout(() => {
        window.location.href = redirect_url
      }, 1200)
    } catch {
      setLoading(false)
      setError(true)
    }
  }

  return (
    <div className="bg-glow grid min-h-screen place-items-center px-4">
      <div className="w-full max-w-sm">
        <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-card)] p-8 shadow-2xl shadow-black/50">
          <div className="flex flex-col items-center text-center">
            <div className="grid h-14 w-14 place-items-center rounded-xl bg-gradient-to-br from-blue-500 to-blue-700 text-2xl font-bold text-white shadow-lg shadow-blue-900/50">
              S
            </div>
            <h1 className="mt-4 text-xl font-bold text-[var(--color-text)]">SAS Relay</h1>
            <p className="text-sm text-[var(--color-muted)]">SMS Gateway Portal</p>
          </div>

          {error && (
            <div className="mt-6 rounded-md border border-red-500/40 bg-red-500/10 p-3 text-center text-sm text-red-300">
              Your account is not in an authorized group. Contact your administrator.
            </div>
          )}

          <button
            onClick={signIn}
            disabled={loading}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-[var(--color-accent)] px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-900/40 transition hover:shadow-blue-700/50 hover:brightness-110 disabled:opacity-70"
          >
            {loading ? (
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/40 border-t-white" />
            ) : (
              <>
                <LayoutGrid size={17} />
                Sign in with Microsoft
              </>
            )}
          </button>

          <p className="mt-4 text-center text-xs text-[var(--color-muted)]">
            Access restricted to WVT authorized AD groups
          </p>
        </div>
      </div>
    </div>
  )
}
