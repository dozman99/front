import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Download } from 'lucide-react'
import TopBar from '../components/layout/TopBar'
import RoleGuard from '../components/layout/RoleGuard'
import ProgressBar from '../components/shared/ProgressBar'
import { useIsAdmin } from '../store/authStore'
import { useToast } from '../store/uiStore'
import { relativeTime, formatDateTime, formatNumber } from '../lib/utils'
import {
  getStats,
  getIncidents,
  getActivity,
  getUsage,
  type UsagePeriod,
} from '../api/dashboard'
import { listThrottle, getGlobalThrottle, patchGlobalThrottle } from '../api/throttle'
import { listAudit, exportAudit } from '../api/audit'
import {
  Line,
  XAxis,
  YAxis,
  ReferenceLine,
  ResponsiveContainer,
  Area,
  ComposedChart,
} from 'recharts'

type Tab = 'overview' | 'throttle' | 'audit'

export default function Dashboard() {
  const isAdmin = useIsAdmin()
  const [tab, setTab] = useState<Tab>('overview')

  return (
    <>
      <TopBar title="Dashboard" />
      <main className="flex-1 overflow-y-auto p-5">
        <div className="mb-5 flex gap-1 border-b border-[var(--color-border)]">
          <TabButton active={tab === 'overview'} onClick={() => setTab('overview')}>
            Overview
          </TabButton>
          {isAdmin && (
            <>
              <TabButton active={tab === 'throttle'} onClick={() => setTab('throttle')}>
                Throttle
              </TabButton>
              <TabButton active={tab === 'audit'} onClick={() => setTab('audit')}>
                Audit Log
              </TabButton>
            </>
          )}
        </div>

        {tab === 'overview' && <Overview />}
        {tab === 'throttle' && isAdmin && <Throttle />}
        {tab === 'audit' && isAdmin && <AuditLog />}
      </main>
    </>
  )
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      className={`-mb-px border-b-2 px-4 py-2 text-sm font-medium transition ${
        active
          ? 'border-[var(--color-accent)] text-[var(--color-text)]'
          : 'border-transparent text-[var(--color-muted)] hover:text-[var(--color-text)]'
      }`}
    >
      {children}
    </button>
  )
}

/* ---------------- OVERVIEW TAB ---------------- */

const SEV_BORDER: Record<string, string> = {
  critical: 'border-l-[var(--color-critical)]',
  warning: 'border-l-[var(--color-warning)]',
  info: 'border-l-[var(--color-accent)]',
}

function Overview() {
  const isAdmin = useIsAdmin()
  const [period, setPeriod] = useState<UsagePeriod>('today')

  const stats = useQuery({ queryKey: ['dashboard', 'stats'], queryFn: getStats })
  const incidents = useQuery({ queryKey: ['dashboard', 'incidents'], queryFn: getIncidents })
  const activity = useQuery({ queryKey: ['dashboard', 'activity'], queryFn: getActivity })
  const usage = useQuery({
    queryKey: ['dashboard', 'usage', period],
    queryFn: () => getUsage(period),
    enabled: isAdmin,
  })

  const s = stats.data

  return (
    <div className="space-y-6">
      {/* Stats row */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          color="var(--color-critical)"
          label="Banned Apps"
          value={s?.banned_apps ?? 0}
          sub={`${s?.banned_phones ?? 0} phones banned`}
        />
        <StatCard
          color="var(--color-warning)"
          label="Temp Bans"
          value={s?.temp_expiring_today ?? 0}
          sub="expiring today"
        />
        <StatCard
          color="var(--color-accent)"
          label="Opt-Outs"
          value={s?.opt_outs ?? 0}
          sub="total"
        />
        <StatCard
          color="var(--color-safe)"
          label="Throttled Today"
          value={s?.throttled_today ?? 0}
          sub={`${s?.cap_hits_today ?? 0} cap hits`}
        />
      </div>

      {/* Needs Attention */}
      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-[var(--color-muted)]">
          Needs Attention
        </h2>
        <div className="space-y-2">
          {(incidents.data ?? []).length === 0 && (
            <p className="text-sm text-[var(--color-muted)]">Nothing needs attention right now.</p>
          )}
          {(incidents.data ?? []).map((inc, i) => (
            <div
              key={i}
              className={`flex items-center justify-between rounded-lg border border-[var(--color-border)] border-l-4 bg-[var(--color-card)] p-3 ${
                SEV_BORDER[inc.severity] ?? SEV_BORDER.info
              }`}
            >
              <div className="min-w-0">
                <p className="mono truncate text-sm font-medium text-[var(--color-text)]">
                  {inc.entity}
                </p>
                <p className="text-xs text-[var(--color-muted)]">{inc.detail}</p>
              </div>
              {/* Admin sees action buttons; helpdesk sees View only. */}
              <RoleGuard>
                <div className="flex shrink-0 gap-1.5">
                  <SmallBtn>View</SmallBtn>
                  <SmallBtn>Extend</SmallBtn>
                  <SmallBtn>Lift Ban</SmallBtn>
                </div>
              </RoleGuard>
              {!isAdmin && <SmallBtn>View</SmallBtn>}
            </div>
          ))}
        </div>
      </section>

      {/* Two column: usage + activity */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        {isAdmin && (
          <section className="rounded-lg border border-[var(--color-border)] bg-[var(--color-card)] p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-[var(--color-text)]">Usage</h2>
              <div className="flex gap-1">
                {(['today', 'week', 'month', 'all'] as UsagePeriod[]).map((p) => (
                  <button
                    key={p}
                    onClick={() => setPeriod(p)}
                    className={`rounded px-2 py-1 text-xs capitalize ${
                      period === p
                        ? 'bg-[var(--color-accent)]/15 text-blue-300'
                        : 'text-[var(--color-muted)] hover:text-[var(--color-text)]'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <UsageBars data={usage.data} />
          </section>
        )}

        <section className="rounded-lg border border-[var(--color-border)] bg-[var(--color-card)] p-4">
          <h2 className="mb-3 text-sm font-semibold text-[var(--color-text)]">Recent Activity</h2>
          <div className="space-y-2.5">
            {(activity.data ?? []).map((a) => (
              <div key={a.id} className="flex items-center gap-2.5 text-sm">
                <span
                  className="h-2 w-2 shrink-0 rounded-full"
                  style={{ backgroundColor: activityColor(a.action) }}
                />
                <span className="mono truncate text-[var(--color-text)]">{a.entity}</span>
                <span className="text-[var(--color-muted)]">{a.action}</span>
                <span className="ml-auto shrink-0 text-xs text-[var(--color-muted)]">
                  {relativeTime(a.performed_at)}
                </span>
              </div>
            ))}
            {(activity.data ?? []).length === 0 && (
              <p className="text-sm text-[var(--color-muted)]">No recent activity.</p>
            )}
          </div>
        </section>
      </div>
    </div>
  )
}

function activityColor(action: string): string {
  const a = action.toLowerCase()
  if (a.includes('unban')) return 'var(--color-safe)'
  if (a.includes('temp')) return 'var(--color-warning)'
  if (a.includes('opt')) return '#94a3b8'
  if (a.includes('ban')) return 'var(--color-critical)'
  return 'var(--color-accent)'
}

function StatCard({
  color,
  label,
  value,
  sub,
}: {
  color: string
  label: string
  value: number
  sub: string
}) {
  return (
    <div
      className="relative overflow-hidden rounded-lg border border-[var(--color-border)] bg-[var(--color-card)] p-4"
      style={{ borderTopColor: color, borderTopWidth: 2 }}
    >
      <div
        className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-20 blur-2xl"
        style={{ backgroundColor: color }}
      />
      <p className="text-xs uppercase tracking-wide text-[var(--color-muted)]">{label}</p>
      <p className="mono mt-1 text-2xl font-bold text-[var(--color-text)]">
        {formatNumber(value)}
      </p>
      <p className="text-xs text-[var(--color-muted)]">{sub}</p>
    </div>
  )
}

function UsageBars({ data }: { data?: import('../types').UsageData }) {
  const rows: Array<[string, number]> = [
    ['Attempted', data?.attempted ?? 0],
    ['Delivered', data?.delivered ?? 0],
    ['Throttled', data?.throttled ?? 0],
    ['Blocked', data?.blocked ?? 0],
    ['Opt-Out', data?.opt_out ?? 0],
    ['Cap Hits', data?.cap_hits ?? 0],
  ]
  const max = Math.max(1, ...rows.map(([, v]) => v))
  return (
    <div className="space-y-3">
      {rows.map(([label, val]) => (
        <div key={label}>
          <div className="mb-1 flex items-center justify-between text-sm">
            <span className="text-[var(--color-muted)]">{label}</span>
            <span className="mono text-[var(--color-text)]">{formatNumber(val)}</span>
          </div>
          <ProgressBar value={val} max={max} />
        </div>
      ))}
    </div>
  )
}

function SmallBtn({ children }: { children: React.ReactNode }) {
  return (
    <button className="rounded border border-[var(--color-border)] px-2 py-1 text-xs text-[var(--color-text)] hover:bg-[var(--color-surface)]">
      {children}
    </button>
  )
}

/* ---------------- THROTTLE TAB (admin) ---------------- */

function Throttle() {
  const qc = useQueryClient()
  const toast = useToast()
  const global = useQuery({ queryKey: ['throttle', 'global'], queryFn: getGlobalThrottle })
  const list = useQuery({ queryKey: ['throttle'], queryFn: listThrottle })
  const [cap, setCap] = useState<string>('')

  const saveGlobal = useMutation({
    mutationFn: () => patchGlobalThrottle({ cap_per_hour: Number(cap) }),
    onSuccess: () => {
      toast('success', 'Global cap updated')
      qc.invalidateQueries({ queryKey: ['throttle'] })
    },
    onError: () => toast('error', 'Could not update cap'),
  })

  // Mock 24h series scaffold — real data arrives via polling on the rate field.
  const chartData = (list.data ?? []).slice(0, 1).flatMap(() =>
    Array.from({ length: 24 }, (_, h) => ({
      hour: `${h}:00`,
      rate: Math.round(Math.random() * 80),
    }))
  )
  const capLine = global.data?.cap_per_hour ?? 100

  return (
    <div className="space-y-6">
      <div className="flex items-end gap-3 rounded-lg border border-[var(--color-border)] bg-[var(--color-card)] p-4">
        <div>
          <label className="block text-xs uppercase tracking-wide text-[var(--color-muted)]">
            Global default cap (per hour)
          </label>
          <input
            type="number"
            value={cap}
            onChange={(e) => setCap(e.target.value)}
            placeholder={String(global.data?.cap_per_hour ?? '')}
            className="mono mt-1 w-32 rounded-md border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-2 text-sm text-[var(--color-text)]"
          />
        </div>
        <button
          onClick={() => saveGlobal.mutate()}
          disabled={!cap || saveGlobal.isPending}
          className="rounded-md bg-[var(--color-accent)] px-4 py-2 text-sm font-medium text-white disabled:opacity-40"
        >
          Save
        </button>
      </div>

      <div className="rounded-lg border border-[var(--color-border)] bg-[var(--color-card)] p-4">
        <h2 className="mb-3 text-sm font-semibold text-[var(--color-text)]">
          Message rate — last 24 hours
        </h2>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData}>
              <defs>
                <linearGradient id="rateFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563eb" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#2563eb" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="hour" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={11} />
              <Area type="monotone" dataKey="rate" stroke="none" fill="url(#rateFill)" />
              <Line type="monotone" dataKey="rate" stroke="#2563eb" dot={false} strokeWidth={2} />
              <ReferenceLine y={capLine} stroke="#dc2626" strokeDasharray="6 4" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-[var(--color-border)]">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--color-border)] bg-[var(--color-surface)] text-left text-xs uppercase text-[var(--color-muted)]">
              <th className="px-4 py-2.5">App email</th>
              <th className="px-4 py-2.5">Cap/hr</th>
              <th className="px-4 py-2.5">Enabled</th>
              <th className="px-4 py-2.5">Updated</th>
            </tr>
          </thead>
          <tbody>
            {(list.data ?? []).map((t) => (
              <tr key={t.email_address} className="border-b border-[var(--color-border)] last:border-0">
                <td className="mono px-4 py-3 text-[var(--color-text)]">{t.email_address}</td>
                <td className="mono px-4 py-3 text-[var(--color-text)]">{t.cap_per_hour}</td>
                <td className="px-4 py-3 text-[var(--color-muted)]">{t.enabled ? 'Yes' : 'No'}</td>
                <td className="px-4 py-3 text-[var(--color-muted)]">{relativeTime(t.updated_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ---------------- AUDIT LOG TAB (admin) ---------------- */

const ACTION_COLOR: Record<string, string> = {
  'PERM BAN': 'var(--color-critical)',
  UNBAN: 'var(--color-safe)',
  'TEMP BAN': 'var(--color-warning)',
  'AUTO BAN': 'var(--color-warning)',
  'OPT-OUT': '#94a3b8',
}

function AuditLog() {
  const toast = useToast()
  const [page] = useState(1)
  const audit = useQuery({
    queryKey: ['audit', { page, limit: 50 }],
    queryFn: () => listAudit({ page, limit: 50 }),
  })

  async function doExport() {
    try {
      const blob = await exportAudit({})
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'audit-log.csv'
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      toast('error', 'Export failed')
    }
  }

  return (
    <div className="space-y-3">
      <div className="overflow-x-auto rounded-lg border border-[var(--color-border)]">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--color-border)] bg-[var(--color-surface)] text-left text-xs uppercase text-[var(--color-muted)]">
              <th className="px-4 py-2.5">Action</th>
              <th className="px-4 py-2.5">Entity</th>
              <th className="px-4 py-2.5">By</th>
              <th className="px-4 py-2.5">Time</th>
              <th className="px-4 py-2.5">Reason</th>
            </tr>
          </thead>
          <tbody>
            {(audit.data?.results ?? []).map((r) => (
              <tr
                key={r.id}
                className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-accent)]/5"
              >
                <td className="px-4 py-3">
                  <span
                    className="text-xs font-semibold"
                    style={{ color: ACTION_COLOR[r.action] ?? 'var(--color-text)' }}
                  >
                    {r.action}
                  </span>
                </td>
                <td className="mono px-4 py-3 text-[var(--color-text)]">{r.entity_value}</td>
                <td className="px-4 py-3 text-[var(--color-muted)]">{r.performed_by}</td>
                <td className="px-4 py-3 text-[var(--color-muted)]">
                  {formatDateTime(r.performed_at)}
                </td>
                <td className="px-4 py-3 text-[var(--color-muted)]">{r.reason ?? '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex justify-end">
        <button
          onClick={doExport}
          className="flex items-center gap-1.5 rounded-md border border-[var(--color-border)] px-3 py-2 text-sm text-[var(--color-text)] hover:bg-[var(--color-surface)]"
        >
          <Download size={15} /> Export CSV
        </button>
      </div>
    </div>
  )
}
