import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Plus, RefreshCw, Trash2, Pencil } from 'lucide-react'
import TopBar from '../components/layout/TopBar'
import { useToast } from '../store/uiStore'
import { relativeTime, classNames } from '../lib/utils'
import {
  listGroups,
  createGroup,
  deleteGroup,
  syncGroups,
} from '../api/groups'
import { listRules, createRule, patchRule } from '../api/rules'
import type { Role, RuleRecord, AdGroupRecord } from '../types'

type Tab = 'groups' | 'rules'

export default function Settings() {
  const [tab, setTab] = useState<Tab>('groups')
  return (
    <>
      <TopBar title="Settings" />
      <main className="flex-1 overflow-y-auto p-5">
        <div className="mb-5 flex gap-1 border-b border-[var(--color-border)]">
          <button onClick={() => setTab('groups')} className={tc(tab === 'groups')}>
            AD Groups
          </button>
          <button onClick={() => setTab('rules')} className={tc(tab === 'rules')}>
            Auto-Ban Rules
          </button>
        </div>
        {tab === 'groups' ? <GroupsTab /> : <RulesTab />}
      </main>
    </>
  )
}

function tc(active: boolean) {
  return classNames(
    '-mb-px border-b-2 px-4 py-2 text-sm font-medium transition',
    active
      ? 'border-[var(--color-accent)] text-[var(--color-text)]'
      : 'border-transparent text-[var(--color-muted)] hover:text-[var(--color-text)]'
  )
}

/* ---------------- AD GROUPS ---------------- */

function GroupsTab() {
  const qc = useQueryClient()
  const toast = useToast()
  const groups = useQuery({ queryKey: ['groups'], queryFn: listGroups })
  const [lastSync, setLastSync] = useState<string | null>(null)
  const [addOpen, setAddOpen] = useState(false)
  const [removeTarget, setRemoveTarget] = useState<AdGroupRecord | null>(null)

  const sync = useMutation({
    mutationFn: syncGroups,
    onMutate: () => toast('info', 'Syncing AD groups'),
    onSuccess: () => {
      toast('success', 'AD groups synced successfully')
      setLastSync(new Date().toISOString())
      qc.invalidateQueries({ queryKey: ['groups'] })
    },
    onError: () => toast('error', 'Sync failed'),
  })

  const remove = useMutation({
    mutationFn: (name: string) => deleteGroup(name),
    onSuccess: () => {
      toast('success', 'Group removed')
      qc.invalidateQueries({ queryKey: ['groups'] })
      setRemoveTarget(null)
    },
    onError: () => toast('error', 'Could not remove group'),
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-[var(--color-muted)]">
          {lastSync ? `Last synced ${relativeTime(lastSync)}` : 'Not synced this session'}
        </p>
        <div className="flex gap-2">
          <button
            onClick={() => sync.mutate()}
            disabled={sync.isPending}
            className="flex items-center gap-1.5 rounded-md border border-[var(--color-border)] px-3 py-1.5 text-sm text-[var(--color-text)] hover:bg-[var(--color-surface)] disabled:opacity-50"
          >
            <RefreshCw size={14} className={sync.isPending ? 'animate-spin' : ''} />
            Sync Now
          </button>
          <button
            onClick={() => setAddOpen(true)}
            className="flex items-center gap-1.5 rounded-md bg-[var(--color-accent)] px-3 py-1.5 text-sm font-medium text-white hover:brightness-110"
          >
            <Plus size={15} /> Add AD Group
          </button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-[var(--color-border)]">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--color-border)] bg-[var(--color-surface)] text-left text-xs uppercase text-[var(--color-muted)]">
              <th className="px-4 py-2.5">AD Group Name</th>
              <th className="px-4 py-2.5">Role</th>
              <th className="px-4 py-2.5">Added</th>
              <th className="px-4 py-2.5" />
            </tr>
          </thead>
          <tbody>
            {(groups.data ?? []).map((g) => (
              <tr key={g.group_name} className="border-b border-[var(--color-border)] last:border-0">
                <td className="mono px-4 py-3 text-[var(--color-text)]">{g.group_name}</td>
                <td className="px-4 py-3">
                  <RoleBadge role={g.role} />
                </td>
                <td className="px-4 py-3 text-xs text-[var(--color-muted)]">
                  {g.added_by ?? '—'} · {relativeTime(g.added_at)}
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => setRemoveTarget(g)}
                    className="rounded p-1.5 text-red-400 hover:bg-red-500/10"
                    aria-label="Remove group"
                  >
                    <Trash2 size={15} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {addOpen && (
        <AddGroupModal
          onClose={() => setAddOpen(false)}
          onAdd={async (body) => {
            await createGroup(body)
            toast('success', 'Group added')
            qc.invalidateQueries({ queryKey: ['groups'] })
            setAddOpen(false)
          }}
        />
      )}

      {removeTarget && (
        <Modal title={`Remove ${removeTarget.group_name}?`} onClose={() => setRemoveTarget(null)}>
          <p className="text-sm text-[var(--color-muted)]">
            Removing this group will revoke access immediately. Users lose access on their next
            request.
          </p>
          <div className="mt-5 flex justify-end gap-2">
            <GhostBtn onClick={() => setRemoveTarget(null)}>Cancel</GhostBtn>
            <button
              onClick={() => remove.mutate(removeTarget.group_name)}
              className="rounded-md bg-[var(--color-critical)] px-4 py-2 text-sm font-medium text-white"
            >
              Confirm Remove
            </button>
          </div>
        </Modal>
      )}
    </div>
  )
}

function RoleBadge({ role }: { role: Role }) {
  return (
    <span
      className={classNames(
        'rounded-full px-2 py-0.5 text-xs font-medium',
        role === 'admin' ? 'bg-green-500/10 text-green-300' : 'bg-blue-500/10 text-blue-300'
      )}
    >
      {role === 'admin' ? 'Admin' : 'Helpdesk'}
    </span>
  )
}

function AddGroupModal({
  onClose,
  onAdd,
}: {
  onClose: () => void
  onAdd: (body: { group_name: string; role: Role }) => Promise<void>
}) {
  const [name, setName] = useState('')
  const [role, setRole] = useState<Role>('helpdesk')
  const [busy, setBusy] = useState(false)

  return (
    <Modal title="Add AD Group" onClose={onClose}>
      <div className="space-y-3">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="WVT-SAS-Admins"
          className="mono w-full rounded-md border border-[var(--color-border)] bg-[var(--color-card)] px-3 py-2 text-sm text-[var(--color-text)]"
        />
        <div className="flex gap-3 text-sm text-[var(--color-text)]">
          {(['admin', 'helpdesk'] as Role[]).map((r) => (
            <label key={r} className="flex items-center gap-2">
              <input type="radio" checked={role === r} onChange={() => setRole(r)} />
              {r === 'admin' ? 'Admin' : 'Helpdesk'}
            </label>
          ))}
        </div>
      </div>
      <div className="mt-5 flex justify-end gap-2">
        <GhostBtn onClick={onClose}>Cancel</GhostBtn>
        <button
          disabled={!name.trim() || busy}
          onClick={async () => {
            setBusy(true)
            try {
              await onAdd({ group_name: name.trim(), role })
            } finally {
              setBusy(false)
            }
          }}
          className="rounded-md bg-[var(--color-accent)] px-4 py-2 text-sm font-medium text-white disabled:opacity-40"
        >
          Add Group
        </button>
      </div>
    </Modal>
  )
}

/* ---------------- AUTO-BAN RULES ---------------- */

function RulesTab() {
  const qc = useQueryClient()
  const toast = useToast()
  const rules = useQuery({ queryKey: ['rules'], queryFn: listRules })
  const [editing, setEditing] = useState<RuleRecord | null>(null)
  const [adding, setAdding] = useState(false)

  const toggle = useMutation({
    mutationFn: ({ id, enabled }: { id: number; enabled: boolean }) =>
      patchRule(id, { enabled }),
    onSuccess: () => {
      toast('success', 'Rule updated')
      qc.invalidateQueries({ queryKey: ['rules'] })
    },
  })

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button
          onClick={() => setAdding(true)}
          className="flex items-center gap-1.5 rounded-md bg-[var(--color-accent)] px-3 py-1.5 text-sm font-medium text-white hover:brightness-110"
        >
          <Plus size={15} /> Add Rule
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        {(rules.data ?? []).map((rule) => (
          <div
            key={rule.id}
            className={classNames(
              'rounded-lg border bg-[var(--color-card)] p-4 transition',
              rule.enabled
                ? 'border-[var(--color-border)] opacity-100'
                : 'border-[var(--color-border)]/50 opacity-50'
            )}
          >
            <div className="flex items-start justify-between gap-2">
              <h3 className="text-base font-bold text-[var(--color-text)]">{rule.title}</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setEditing(rule)}
                  className="rounded p-1 text-[var(--color-muted)] hover:text-[var(--color-text)]"
                  aria-label="Edit rule"
                >
                  <Pencil size={14} />
                </button>
                <Switch
                  on={rule.enabled}
                  onClick={() => toggle.mutate({ id: rule.id, enabled: !rule.enabled })}
                />
              </div>
            </div>
            <p className="mt-2 text-sm text-[var(--color-text)]">
              <span className="text-[var(--color-muted)]">IF</span> {rule.condition_text}
            </p>
            <p className="mt-1 text-sm text-blue-300">
              <span className="text-[var(--color-muted)]">THEN</span> {rule.action_text}
            </p>
          </div>
        ))}
      </div>

      {(adding || editing) && (
        <RuleModal
          rule={editing}
          onClose={() => {
            setAdding(false)
            setEditing(null)
          }}
          onSave={async (body) => {
            if (editing) {
              await patchRule(editing.id, body)
              toast('success', 'Rule saved')
            } else {
              await createRule(body)
              toast('success', 'Rule created')
            }
            qc.invalidateQueries({ queryKey: ['rules'] })
            setAdding(false)
            setEditing(null)
          }}
        />
      )}
    </div>
  )
}

function Switch({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      role="switch"
      aria-checked={on}
      className={classNames(
        'relative h-5 w-9 rounded-full transition',
        on ? 'bg-[var(--color-accent)]' : 'bg-[var(--color-border)]'
      )}
    >
      <span
        className={classNames(
          'absolute top-0.5 h-4 w-4 rounded-full bg-white transition',
          on ? 'left-4' : 'left-0.5'
        )}
      />
    </button>
  )
}

function RuleModal({
  rule,
  onClose,
  onSave,
}: {
  rule: RuleRecord | null
  onClose: () => void
  onSave: (body: { title: string; condition_text: string; action_text: string }) => Promise<void>
}) {
  const [title, setTitle] = useState(rule?.title ?? '')
  const [condition, setCondition] = useState(rule?.condition_text ?? '')
  const [action, setAction] = useState(rule?.action_text ?? '')
  const [busy, setBusy] = useState(false)

  return (
    <Modal title={rule ? 'Edit Rule' : 'Add Rule'} onClose={onClose}>
      <div className="space-y-3">
        <Field label="Title" value={title} onChange={setTitle} />
        <Field label="Condition" value={condition} onChange={setCondition} />
        <Field label="Action" value={action} onChange={setAction} />
      </div>
      <div className="mt-5 flex justify-end gap-2">
        <GhostBtn onClick={onClose}>Cancel</GhostBtn>
        <button
          disabled={!title.trim() || busy}
          onClick={async () => {
            setBusy(true)
            try {
              await onSave({
                title: title.trim(),
                condition_text: condition.trim(),
                action_text: action.trim(),
              })
            } finally {
              setBusy(false)
            }
          }}
          className="rounded-md bg-[var(--color-accent)] px-4 py-2 text-sm font-medium text-white disabled:opacity-40"
        >
          Save Rule
        </button>
      </div>
    </Modal>
  )
}

function Field({
  label,
  value,
  onChange,
}: {
  label: string
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div>
      <label className="block text-xs uppercase tracking-wide text-[var(--color-muted)]">
        {label}
      </label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-md border border-[var(--color-border)] bg-[var(--color-card)] px-3 py-2 text-sm text-[var(--color-text)]"
      />
    </div>
  )
}

/* ---------------- Shared modal ---------------- */

function Modal({
  title,
  onClose,
  children,
}: {
  title: string
  onClose: () => void
  children: React.ReactNode
}) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} aria-hidden />
      <div className="relative w-full max-w-md rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)] p-5 shadow-2xl shadow-black/60">
        <h2 className="mb-4 text-base font-bold text-[var(--color-text)]">{title}</h2>
        {children}
      </div>
    </div>
  )
}

function GhostBtn({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="rounded-md border border-[var(--color-border)] px-4 py-2 text-sm text-[var(--color-text)] hover:bg-[var(--color-card)]"
    >
      {children}
    </button>
  )
}
